<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Inclure PHPMailer via le chemin correct dans le dossier lib
require_once __DIR__ . '/../lib/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../lib/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../lib/PHPMailer-master/src/Exception.php';

session_start();

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION['email'])) {
    echo "Utilisateur non connecté";
    exit();
}

// Configurations de la base de données
$host = 'localhost';
$db = 'monprojet_db';
$user = 'Tharindu';
$password = '';

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}

// Récupérer l'email de l'utilisateur connecté depuis la session
$email = $_SESSION['email'];

// Initialiser les variables pour pré-remplir le formulaire
$prenom = $nom = $nationalite = $numPasseport = '';

// Récupérer les informations de l'utilisateur connecté
$sql = "SELECT id, prenom, nom, nationalite FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($userId, $prenom, $nom, $nationalite);
$stmt->fetch();
$stmt->close();

// Récupérer le numéro de passeport de l'utilisateur
$sql = "SELECT num_passeport FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($numPasseport);
$stmt->fetch();
$stmt->close();

// Vérifier si une demande de visa est déjà en cours pour cet utilisateur
$sql = "SELECT * FROM visa_requests WHERE user_id = ? AND statut = 'en cours'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$demandeExiste = $result->num_rows > 0;
$stmt->close();

// Traitement du formulaire d'envoi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !$demandeExiste) {
    $passportNumber = $_POST['passport-number'];
    $regex = '/^[0-9]{2}[a-zA-Z]{2}[0-9]{5}$/';

    // Validation du format du numéro de passeport
    if (!preg_match($regex, $passportNumber)) {
        echo "<script>alert('Le numéro de passeport est incorrect : il doit être composé de deux chiffres, deux lettres, puis cinq chiffres.');</script>";
    } else {
        // Débuter une transaction pour assurer l'intégrité des mises à jour
        $conn->begin_transaction();

        try {
            // Ajouter une nouvelle demande de visa pour cet utilisateur dans `visa_requests`
            $sql = "INSERT INTO visa_requests (user_id, num_passeport, statut) VALUES (?, ?, 'en cours')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $userId, $passportNumber);
            $stmt->execute();
            $stmt->close();

            // Mettre à jour le numéro de passeport dans `users`
            $sql = "UPDATE users SET num_passeport = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $passportNumber, $userId);
            $stmt->execute();
            $stmt->close();

            // Valider la transaction
            $conn->commit();

            // Générer le PDF récapitulatif de la demande
            require('../lib/fpdf.php');
            $pdf = new FPDF();
            $pdf->AddPage();

            // Ajouter la police Arial, compatible avec les caractères accentués
            $pdf->SetFont('Arial', '', 12);

            // Ajouter l'entête de la lettre
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(200, 10, 'Ambassade du Sri Lanka en France', 0, 1, 'C');
            $pdf->SetFont('Arial', '', 12);
            $pdf->Cell(200, 10, '16 Rue Spontini, 75016 Paris', 0, 1, 'C');
            $pdf->Cell(200, 10, 'Telephone : 0155733131', 0, 1, 'C');
            $pdf->Ln(10);

            // Ajouter la date
            $pdf->Cell(100, 10, 'Date : ' . date('d/m/Y'), 0, 1);
            $pdf->Ln(10);

            // Objet de la lettre
            $pdf->SetFont('Arial', 'B', 12);
            $pdf->Cell(200, 10, 'Objet : Confirmation de reception de la demande de visa', 0, 1);
            $pdf->Ln(10);

            // Corps de la lettre
            $pdf->SetFont('Arial', '', 12);
            $corps = "Madame, Monsieur,\n\nNous vous confirmons avoir bien recu votre demande de visa pour le Sri Lanka, soumise sur notre plateforme en ligne. Votre dossier est actuellement en cours de traitement par nos services.\n\nVoici un recapitulatif de votre demande :\n\nNom complet : " . $nom . " " . $prenom . "\nNuméro de passeport : " . $numPasseport . "\nDate de soumission : " . date('d/m/Y') . "\n\nNous vous contacterons dans les plus brefs delais pour vous informer de l'evolution de votre demande. Si des documents complementaires sont necessaires, vous en serez informe par email.\n\nNous vous remercions pour votre confiance et restons a votre disposition pour toute question.\n\nCordialement, Ambassade du Sri Lanka en France";

            // Utilisation de MultiCell pour que le texte soit automatiquement ajusté à la page
            $pdf->MultiCell(0, 10, $corps);

            // Ajouter un petit espace avant la signature pour s'assurer que tout tienne sur une seule page
            $pdf->Ln(10);

            // Sauvegarder le PDF dans un fichier
            $pdfPath = '../demandes_visa/' . $nom . '_demande_visa.pdf';
            $pdf->Output('F', $pdfPath);

            // Envoi de l'email de confirmation via PHPMailer
            $mail = new PHPMailer\PHPMailer\PHPMailer();
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'consulatsri@gmail.com'; // Ton adresse email
                $mail->Password = 'imzm nfjs zzqy hkyi'; // Ton mot de passe d'application
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Expéditeur et destinataire
                $mail->setFrom('consulatsri@gmail.com', 'Ambassade Sri Lanka');
                $mail->addAddress($email, $prenom . ' ' . $nom);

                // Sujet et corps de l'email
                $mail->isHTML(true);
                $mail->Subject = 'Confirmation de votre demande de visa';
                $mail->Body    = 'Bonjour ' . $prenom . ',<br><br>Nous avons bien reçu votre demande de visa. Vous trouverez en pièce jointe un récapitulatif de votre demande.';

                // Ajouter le PDF en pièce jointe
                $mail->addAttachment($pdfPath);

                $mail->send();

                echo "<script>alert('Un récapitutaltif de votre demande vous a été envoyez par mail');</script>";
            } catch (Exception $e) {
                echo "<script>alert('Erreur lors de l\'envoi de l\'email: {$mail->ErrorInfo}');</script>";
            }
        } catch (Exception $e) {
            // Annuler la transaction en cas d'erreur
            $conn->rollback();
            echo "<script>alert('Erreur lors de l\'insertion de la demande: " . $e->getMessage() . "');</script>";
        }
    }
}

// Fermeture de la connexion à la base de données
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demande de Visa - Consulat du Sri Lanka</title>
    <link rel="stylesheet" href="../style/visa.css">
    <script>
        function validatePassport() {
            const passportNumber = document.getElementById("passport-number").value;
            const regex = /^[0-9]{2}[a-zA-Z]{2}[0-9]{5}$/;
            if (!regex.test(passportNumber)) {
                alert("Le numero de passeport est incorrect : il doit être compose de deux chiffres, deux lettres, puis cinq chiffres.");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <header class="top-header">
        <div class="logo-container">
            <img src="../images/drapeau_sri_lanka.jpg" alt="Drapeau du Sri Lanka" class="flag-img">
            <h1>Consulat du Sri Lanka</h1>
        </div>
        <div class="auth-buttons">
            <?php if (isset($_SESSION['email'])): ?>
            <a href="mon_compte.php" class="button">Mon compte</a>
            <form method="POST" action="visa.php">
                <button type="submit" name="logout" class="button">Se deconnecter</button>
            </form>
            <?php else: ?>
                <a href="inscription.php" class="button">Inscription</a>
                <a href="connexion.php" class="button">Connexion</a>
            <?php endif; ?>
        </div>
    </header>

    <nav class="main-nav">
        <ul>
            <li><a href="home.php">Accueil</a></li>
            <li><a href="culture.php">Culture</a></li>
            <li><a href="visa.php">Demande de visa</a></li>
            <li><a href="loterie.php">Loterie</a></li>
            <li><a href="home.php#contact">Contact</a></li>
        </ul>
    </nav>

    <main>
        <section class="page-title">
            <h2>Demande de Visa</h2>
        </section>

        <section class="form-container">
            <?php if (!$demandeExiste): ?>
                <form action="visa.php" method="post" enctype="multipart/form-data" onsubmit="return validatePassport()">
                    <label for="first-name">Prenom :</label>
                    <input type="text" id="first-name" name="first-name" value="<?php echo htmlspecialchars($prenom); ?>" required>

                    <label for="last-name">Nom :</label>
                    <input type="text" id="last-name" name="last-name" value="<?php echo htmlspecialchars($nom); ?>" required>

                    <label for="nationality">Nationalite :</label>
                    <input type="text" id="nationality" name="nationality" value="<?php echo htmlspecialchars($nationalite); ?>" readonly required>

                    <label for="passport-number">Numero de Passeport :</label>
                    <input type="text" id="passport-number" name="passport-number" 
                        value="<?php echo htmlspecialchars($numPasseport ?? ''); ?>" 
                        <?php echo $numPasseport ? 'readonly' : ''; ?> required>
                    
                    <label for="passport-photo">Photo du Passeport :</label>
                    <input type="file" id="passport-photo" name="passport-photo" accept="image/*" required>

                    <label for="visa-application-documents"> ETA (PDF, JPG, PNG) :</label>
                    <input type="file" id="visa-application-documents" name="visa-application-documents[]" accept=".pdf,.jpg,.jpeg,.png" multiple>

                    <label for="return-ticket">Billet de retour (PDF, JPG, PNG) :</label>
                    <input type="file" id="return-ticket" name="return-ticket" accept=".pdf,.jpg,.jpeg,.png" required>

                    <button class="a" type="submit">Envoyer la demande</button>
                </form>
            <?php else: ?>
                <p>Vous avez deja une demande de visa en cours. Veuillez attendre qu'elle soit traitee avant de soumettre une nouvelle demande.</p>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 Consulat du Sri Lanka. Tous droits reserves.</p>
        <p>16 Rue Spontini, 75016 Paris | Telephone : 0155733131 | Horaires : Lundi a Vendredi : 9h00 - 17h00</p>
        <div class="footer-links">
            <a href="#">Politique de confidentialite</a> | 
            <a href="#">Conditions d'utilisation</a>
        </div>
    </footer>
</body>
</html>
