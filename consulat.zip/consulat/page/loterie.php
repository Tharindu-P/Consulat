<?php
session_start();  // Démarre la session

// Vérifie si l'utilisateur est connecté
$is_logged_in = isset($_SESSION['email']);

// Si l'utilisateur n'est pas connecté, redirige vers la page de connexion avec un message d'alerte
if (!$is_logged_in) {
    echo "<script>alert('Vous devez être connecté pour accéder à cette page.'); window.location.href='connexion.php';</script>";
    exit(); // Empêche l'exécution du reste de la page si l'utilisateur n'est pas connecté
}

// Si l'utilisateur clique sur "Déconnexion"
if (isset($_POST['logout'])) {
    // Détruire toutes les variables de session
    session_unset();
    // Détruire la session
    session_destroy();
    // Rediriger vers la page de connexion
    header('Location: connexion.php');
    exit();
}

// Connexion à la base de données
$host = 'localhost';
$dbname = 'monprojet_db';
$username = 'Tharindu';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
    exit;
}

// Si le bouton "Tirer un gagnant" est cliqué
if (isset($_POST['drawWinner'])) {
    // Récupérer un utilisateur avec est_national = 0 de manière aléatoire
    try {
        $stmt = $pdo->prepare("SELECT id, prenom, nom FROM users WHERE est_national = 0 ORDER BY RAND() LIMIT 1");
        $stmt->execute();
        $winner = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($winner) {
            // Mettre à jour la base de données pour cet utilisateur et lui attribuer la nationalité
            $updateStmt = $pdo->prepare("UPDATE users SET est_national = 1 WHERE id = :id");
            $updateStmt->bindParam(':id', $winner['id']);
            $updateStmt->execute();

            // Afficher le gagnant sur la page
            $winnerName = $winner['prenom'] . ' ' . $winner['nom'];
        } else {
            $winnerName = 'Aucun participant éligible pour le tirage.';
        }
    } catch (PDOException $e) {
        echo "Erreur lors du tirage du gagnant : " . $e->getMessage();
        exit;
    }
} else {
    $winnerName = ''; // Initialisation si le bouton n'est pas encore cliqué
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loterie de participation</title>
    <link rel="stylesheet" href="../style/loterie.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="logo-container">
            <img src="../images/drapeau_sri_lanka.jpg" alt="Drapeau du Sri Lanka" class="flag-img">
            <h1>Consulat du Sri Lanka</h1>
        </div>
        <div class="auth-buttons">
            <?php if ($is_logged_in): ?>
                <a href="mon_compte.php" class="button">Mon compte</a>
                <form method="POST" action="loterie.php">
                    <button type="submit" name="logout" class="button">Se déconnecter</button>
                </form>
            <?php else: ?>
                <a href="inscription.php" class="button">Inscription</a>
                <a href="connexion.php" class="button">Connexion</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- Navigation -->
    <nav class="main-nav">
        <ul>
            <li><a href="home.php">Accueil</a></li>
            <li><a href="culture.php">Culture</a></li>
            <li><a href="visa.php">Demande de visa</a></li>
            <li><a href="loterie.php">Loterie</a></li>
            <li><a href="home.php#contact">Contact</a></li>
        </ul>
    </nav>

    <h2>Loterie</h2>

    <!-- Section de participation -->
    <div class="form-container">
        <!-- Afficher le gagnant -->
        <?php if ($winnerName): ?>
            <h3>Le gagnant est :</h3>
            <p><?php echo htmlspecialchars($winnerName); ?></p>
        <?php endif; ?>

        <h3>Admin : Tirer un gagnant</h3>
        <!-- Le bouton pour tirer un gagnant -->
        <form method="POST" action="loterie.php">
            <button type="submit" name="drawWinner" class="button">Tirer un gagnant</button>
        </form>

        <h3>Liste des participants ayant la nationalité</h3>
        <div id="participantsList">
            <?php
            // Récupérer tous les utilisateurs ayant la nationalité
            try {
                $stmt = $pdo->prepare("SELECT prenom, nom FROM users WHERE est_national = 1");
                $stmt->execute();
                $participants = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if (count($participants) > 0) {
                    foreach ($participants as $participant) {
                        echo '<p>' . htmlspecialchars($participant['prenom'] . ' ' . $participant['nom']) . '</p>';
                    }
                } else {
                    echo '<p>Aucun participant n\'a été trouvé.</p>';
                }
            } catch (PDOException $e) {
                echo "Erreur lors de la récupération des participants : " . $e->getMessage();
            }
            ?>
        </div>

    </div>

<footer>
    <p>&copy; 2023 Consulat du Sri Lanka. Tous droits réservés.</p>
    <p>16 Rue Spontini, 75016 Paris | Téléphone : 0155733131 | Horaires : Lundi à Vendredi : 9h00 - 17h00</p>
    <div class="footer-links">
        <a href="#">Politique de confidentialité</a> | 
        <a href="#">Conditions d'utilisation</a>
    </div>
</footer>

</body>
</html>
