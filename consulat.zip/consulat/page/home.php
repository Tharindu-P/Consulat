<?php
session_start();

// Traitement de la déconnexion
if (isset($_POST['logout'])) {
    // Supprime les variables de session
    session_unset();
    
    // Détruit la session
    session_destroy();
    
    // Redirige l'utilisateur vers la page d'accueil après déconnexion
    header("Location: home.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulat du Sri Lanka</title>
    <link rel="stylesheet" href="../style/home.css">
</head>
<body>
    <!-- Premier header avec le drapeau, le titre et les boutons -->
    <header class="top-header">
        <div class="logo-container">
            <img src="../images/drapeau_sri_lanka.jpg" alt="Drapeau du Sri Lanka" class="flag-img">
            <h1>Consulat du Sri Lanka</h1>
        </div>
        <div class="auth-buttons">
            <!-- Affiche le bouton "Mon compte" et "Se déconnecter" si l'utilisateur est connecté -->
            <?php if (isset($_SESSION['email'])): ?>
            <a href="mon_compte.php" class="button">Mon compte</a>
            <form method="POST">
                <button type="submit" name="logout" class="button">Se déconnecter</button>
            </form>
            <?php else: ?>
                <a href="inscription.php" class="button">Inscription</a>
                <a href="connexion.php" class="button">Connexion</a>
            <?php endif; ?>
        </div>
    </header>

    <!-- Second header avec les liens de navigation -->
    <nav class="main-nav">
        <ul>
            <li><a href="home.php">Accueil</a></li>
            <li><a href="culture.php">Culture</a></li>
            <li><a href="visa.php">Demande de visa</a></li>
            <li><a href="loterie.php">Loterie</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </nav>
    <section class="home-hero">
        <img src="../images/sri_lanka.jpg" alt="Hero Image" class="hero-img">
    </section>
    <main>
        <center><section class="welcome">
            <h2>Bienvenue au Consulat du Sri Lanka</h2>
            <p>Explorez la beauté et la diversité du Sri Lanka, une terre riche en culture, en traditions et en hospitalité. Notre consulat est ici pour vous aider, que vous souhaitiez découvrir notre patrimoine culturel, demander un visa ou participer à notre loterie pour la nationalité.</p>
            <p>Nous nous engageons à fournir un service de qualité à tous nos citoyens et visiteurs. Naviguez facilement à travers nos services et obtenez toutes les informations nécessaires pour votre séjour ou votre expatriation.</p>
        </section></center>
            <section class="services">
                <h2>Nos services</h2>
                <div class="service-items">
                    <div class="service-item">
                        <img src="../images/visa.jpeg" alt="Visa">
                        <h3>Visa</h3>
                        <p>Obtenez votre visa pour le Sri Lanka en quelques clics.</p>
                        <div class="button-container">
                            <a href="visa.php" class="btn">Demander un visa</a>
                        </div>
                    </div>
                    <div class="service-item">
                        <img src="../images/passeport.png" alt="Passeport">
                        <h3>Passeport</h3>
                        <p>Renouvelez votre passeport sri-lankais.</p>
                        <div class="button-container">
                            <a href="#" class="btn">Demander un passeport</a>
                        </div>
                    </div>
                </div>
            </section>

            <section class="contact" id="contact">
                <center><h2>Contactez-nous</h2>
                <h4>Si vous avez des questions ou des demandes, 
                    n'hésitez pas à nous contacter via le formulaire ci-dessous ou en utilisant 
                    nos coordonnées</h4></center>
                <div class="form-container"> <!-- Conteneur pour le formulaire -->
                    <form>
                        <label for="name">Nom :</label>
                        <input type="text" id="name" name="name">
            
                        <label for="email">Email :</label>
                        <input type="email" id="email" name="email">
            
                        <label for="subject">Sujet :</label>
                        <input type="text" id="subject" name="subject">
            
                        <label for="message">Message :</label>
                        <textarea id="message" name="message"></textarea>
            
                        <button class = "envoyer" type="submit">Envoyer</button>
                    </form>
                </div>
            </section>
    </main>

    <footer>
    <p>&copy; 2023 Consulat du Sri Lanka. Tous droits réservés.</p>
    <p>16 Rue Spontini, 75016 Paris | Téléphone : 0155733131 | Horaires : Lundi à Vendredi : 9h00 - 17h00</p>
    <div class="footer-links">
        <a href="#">Politique de confidentialité</a> | 
        <a href="#">Conditions d'utilisation</a>
    </div>
</footer>

</body>
</html>
