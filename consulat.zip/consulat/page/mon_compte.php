<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Vérifie si l'utilisateur est connecté
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Vous devez être connecté pour accéder à cette page.'); window.location.href='connexion.php';</script>";
    exit();
}

// Si l'utilisateur clique sur "Déconnexion"
if (isset($_POST['logout'])) {
    // Détruire toutes les variables de session
    session_unset();
    // Détruire la session
    session_destroy();
    // Rediriger vers la page de connexion
    header('Location: connexion.php');
    exit();
}

// Configurations de la base de données
$host = 'localhost';
$db = 'monprojet_db';
$user = 'Tharindu';  // Remplace par ton nom d'utilisateur MySQL
$password = '';  // Remplace par ton mot de passe si tu en as défini un

// Établir la connexion à la base de données
$conn = new mysqli($host, $user, $password, $db);

// Vérifier la connexion
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

// Récupérer l'ID de l'utilisateur connecté
$user_id = $_SESSION['user_id'];

// Récupérer les informations de l'utilisateur
$stmt = $conn->prepare("SELECT nom, prenom, email, telephone, nationalite, num_passeport, est_national FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();

// Vérifier si l'utilisateur existe
if ($stmt->num_rows > 0) {
    $stmt->bind_result($nom, $prenom, $email, $telephone, $nationalite, $num_passeport, $est_national);
    $stmt->fetch();
} else {
    // Si l'utilisateur n'existe pas, redirige
    header('Location: connexion.php');
    exit();
}

// Vérifier si l'utilisateur est un administrateur basé sur l'email
$isAdmin = ($email == 'admin@gmail.com');

// Récupérer le statut de la demande de visa si l'utilisateur a une demande
$visaStatus = null; // Statut de la demande de visa par défaut à null
$visaStmt = $conn->prepare("SELECT statut FROM visa_requests WHERE user_id = ?");
$visaStmt->bind_param("i", $user_id);
$visaStmt->execute();
$visaStmt->store_result();

// Si l'utilisateur a une demande de visa
if ($visaStmt->num_rows > 0) {
    $visaStmt->bind_result($visaStatus);
    $visaStmt->fetch();
}

// Récupérer les demandes de visa si l'utilisateur est admin
$visaRequestsResult = null; // Variable définie à null pour les autres utilisateurs
if ($isAdmin) {
    $visaRequestsStmt = $conn->prepare("SELECT r.id, u.nom, u.prenom, r.statut, r.date_creation FROM visa_requests r JOIN users u ON r.user_id = u.id");
    $visaRequestsStmt->execute();
    $visaRequestsResult = $visaRequestsStmt->get_result();
}

// Traitement pour accepter ou refuser une demande (uniquement pour l'administrateur)
if (isset($_POST['action']) && isset($_POST['visa_id'])) {
    $visa_id = $_POST['visa_id'];
    $action = $_POST['action'];

    // Vérifier si l'action est valide (accepter ou refuser) et correspond à l'énumération dans la BD
    if ($action == 'accepter' || $action == 'refuser') {
        // Le statut dans la BD peut être 'approuvée' pour 'accepter' et 'refusée' pour 'refuser'
        $new_status = ($action == 'accepter') ? 'approuvée' : 'refusée';

        // Mettre à jour le statut de la demande
        $updateStmt = $conn->prepare("UPDATE visa_requests SET statut = ? WHERE id = ?");
        $updateStmt->bind_param("si", $new_status, $visa_id);

        if ($updateStmt->execute()) {
            echo "<script>alert('La demande de visa a été mise à jour avec succès.'); window.location.href = 'mon_compte.php';</script>";
        } else {
            echo "<script>alert('Erreur lors de la mise à jour de la demande de visa.');</script>";
        }

        $updateStmt->close();
    }
}

$stmt->close();
$visaStmt->close();
if ($isAdmin) {
    $visaRequestsStmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon compte</title>
    <link rel="stylesheet" href="../style/mon_compte.css">
</head>
<body>

<header>
    <div class="logo-container">
        <img src="../images/drapeau_sri_lanka.jpg" alt="Drapeau du Sri Lanka" class="flag-img">
        <h1>Consulat du Sri Lanka</h1>
    </div>
    <div class="auth-buttons">
        <a href="mon_compte.php" class="button">Mon compte</a>
        <form method="POST" action="mon_compte.php">
            <button type="submit" name="logout" class="button">Déconnexion</button>
        </form>
    </div>
</header>

<nav class="main-nav">
    <ul>
        <li><a href="home.php">Accueil</a></li>
        <li><a href="culture.php">Culture</a></li>
        <li><a href="visa.php">Demande de visa</a></li>
        <li><a href="loterie.php">Loterie</a></li>
        <li><a href="home.php#contact">Contact</a></li>
    </ul>
</nav>

<main>
    <section class="account-info">
        <h2>Informations :</h2>
        <table>
            <tr>
                <th>Nom</th>
                <td><?php echo htmlspecialchars($nom); ?></td>
            </tr>
            <tr>
                <th>Prénom</th>
                <td><?php echo htmlspecialchars($prenom); ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?php echo htmlspecialchars($email); ?></td>
            </tr>
            <tr>
                <th>Numéro de téléphone</th>
                <td><?php echo htmlspecialchars($telephone); ?></td>
            </tr>
            <tr>
                <th>Nationalité</th>
                <td><?php echo htmlspecialchars($nationalite); ?></td>
            </tr>
            <tr>
                <th>Nationalité sri lankaise</th>
                <td>
                    <?php echo ($est_national == 1) ? 'Oui' : 'Non'; ?>
                </td>
            </tr>
            <tr>
                <th>Numéro de passeport</th>
                <td>
                    <?php if ($num_passeport) {
                        echo htmlspecialchars($num_passeport);
                    } else { ?>
                        <form method="POST" action="mon_compte.php">
                            <input type="text" name="passport_number" placeholder="Entrez votre numéro de passeport" required>
                            <button type="submit" class="button">Ajouter le passeport</button>
                        </form>
                    <?php } ?>
                </td>
            </tr>
            <!-- Affichage du statut de la demande de visa -->
            <?php if ($visaStatus !== null) { ?>
                <tr>
                    <th>Statut de la demande de visa</th>
                    <td><?php echo htmlspecialchars($visaStatus); ?></td>
                </tr>
            <?php } ?>
        </table>
    </section>

    <!-- Section pour l'administrateur avec les demandes de visa -->
    <?php if ($isAdmin && $visaRequestsResult) { ?>
    <section class="visa-requests">
        <h2>Demandes de Visa</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Statut</th>
                <th>Date de la demande</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = $visaRequestsResult->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['nom']; ?></td>
                    <td><?php echo $row['prenom']; ?></td>
                    <td><?php echo $row['statut']; ?></td>
                    <td><?php echo date("d-m-Y H:i:s", strtotime($row['date_creation'])); ?></td>
                    <td>
                        <?php if ($row['statut'] == 'en cours') { ?>
                            <form method="POST" action="mon_compte.php" style="display:inline;">
                                <input type="hidden" name="visa_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="action" value="accepter" class="button">Accepter</button>
                            </form>
                            <form method="POST" action="mon_compte.php" style="display:inline;">
                                <input type="hidden" name="visa_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="action" value="refuser" class="button">Refuser</button>
                            </form>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </section>
    <?php } ?>
</main>

<footer>
    <p>&copy; 2024 Consulat du Sri Lanka. Tous droits réservés.</p>
</footer>

</body>
</html>
