<?php
session_start();  // Démarre la session

// Si l'utilisateur est déjà connecté, rediriger vers la page d'accueil
if (isset($_SESSION['email'])) {
    header('Location: home.php');
    exit();
}

// Configurations de la base de données
$host = 'localhost';
$db = 'monprojet_db';
$user = 'Tharindu'; // Remplace par ton nom d'utilisateur MySQL
$password = ''; // Remplace par ton mot de passe si tu en as défini un

// Établir la connexion à la base de données
$conn = new mysqli($host, $user, $password, $db);

// Vérifier la connexion
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}
if (isset($_GET['message']) && $_GET['message'] == 'non-connecte') {
    echo "<script>alert('Vous devez être connecté pour accéder à la page de demande de visa.');</script>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        // Traitement de la connexion
        $email = htmlspecialchars($_POST['email']);
        $password = htmlspecialchars($_POST['password']);

        // Vérifie si les champs sont remplis
        if (empty($email) || empty($password)) {
            echo "<script>alert('Veuillez remplir tous les champs.');</script>";
        } else {
            // Requête pour récupérer l'utilisateur correspondant à l'email
            $stmt = $conn->prepare("SELECT id, mot_de_passe FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);  // "s" pour string
            $stmt->execute();
            $stmt->store_result();

            // Vérifier si l'utilisateur existe
            if ($stmt->num_rows > 0) {
                $stmt->bind_result($user_id, $hashed_password);
                $stmt->fetch();

                // Vérifier le mot de passe
                if (password_verify($password, $hashed_password)) {
                    // Si le mot de passe est correct, démarrer la session
                    $_SESSION['email'] = $email;
                    $_SESSION['user_id'] = $user_id;  // Sauvegarde l'ID utilisateur
                    header('Location: home.php');
                    exit();
                } else {
                    echo "<script>alert('Email ou mot de passe incorrect.');</script>";
                }
            } else {
                echo "<script>alert('Email ou mot de passe incorrect.');</script>";
            }
        }
    }
}

// Fermer la connexion
$conn->close();
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="../style/connexion.css">
    <style>
        /* Conteneur des champs de mot de passe */
        .password-container {
            display: flex;
            flex-direction: column; /* Empile les champs de mot de passe */
            width: 100%;
            margin-bottom: 15px;
        }

        .password-container input {
            width: 100%; /* Prend toute la largeur */
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* Style pour le bouton */
        #togglePasswordButton {
            background: none;
            border: none;
            color: #8f1841;
            cursor: pointer;
            font-size: 14px;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Premier header avec le drapeau, le titre et les boutons -->
    <header class="top-header">
        <div class="logo-container">
            <img src="../images/drapeau_sri_lanka.jpg" alt="Drapeau du Sri Lanka" class="flag-img">
            <h1>Consulat du Sri Lanka</h1>
        </div>
        <div class="auth-buttons">
            <a href="inscription.php" class="button">Inscription</a>
            <a href="connexion.php" class="button">Connexion</a>
        </div>
    </header>

    <!-- Second header avec les liens de navigation -->
    <nav class="main-nav">
        <ul>
            <li><a href="home.php">Accueil</a></li>
            <li><a href="culture.php">Culture</a></li>
            <li><a href="visa.php">Demande de visa</a></li>
            <li><a href="loterie.php">Loterie</a></li>
            <li><a href="home.php#contact">Contact</a></li>
        </ul>
    </nav>

    <main>
        <section class="welcome">
            <h2>Connexion</h2>
            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="form-container">
                <!-- Formulaire de Connexion -->
                <form method="POST">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" required>

                    <label for="password">Mot de passe</label>
                    <input type="password" name="password" id="password" required>

                    <!-- Bouton pour afficher/masquer le mot de passe -->
                    <button type="button" id="togglePasswordButton" onclick="togglePassword()">Afficher le mot de passe</button>
                    
                    <button type="submit" name="login">Se connecter</button>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 Consulat du Sri Lanka. Tous droits réservés.</p>
        <p>16 Rue Spontini, 75016 Paris | Téléphone : 0155733131 | Horaires : Lundi à Vendredi : 9h00 - 17h00</p>
        <div class="footer-links">
            <a href="#">Politique de confidentialité</a> | 
            <a href="#">Conditions d'utilisation</a>
        </div>
    </footer>

    <script>
        // Fonction pour afficher/masquer le mot de passe
        function togglePassword() {
            var passwordField = document.getElementById('password');
            var button = document.getElementById('togglePasswordButton');
            
            // Vérifie l'état actuel du champ de mot de passe
            if (passwordField.type === "password") {
                passwordField.type = "text";
                button.textContent = "Masquer le mot de passe"; // Change le texte du bouton
            } else {
                passwordField.type = "password";
                button.textContent = "Afficher le mot de passe"; // Change le texte du bouton
            }
        }
    </script>
</body>
</html>
