<?php
session_start();  // Démarre la session

// Vérifie si l'utilisateur est connecté
$is_logged_in = isset($_SESSION['email']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulat du Sri Lanka</title>
    <!-- Lien vers le fichier CSS qui se trouve dans le dossier style -->
    <link rel="stylesheet" href="../style/culture.css">
</head>
<body>
    <!-- Premier header avec le drapeau, le titre et les boutons -->
    <header class="top-header">
        <div class="logo-container">
            <!-- Lien vers l'image du drapeau -->
            <img src="../images/drapeau_sri_lanka.jpg" alt="Drapeau du Sri Lanka" class="flag-img">
            <h1>Consulat du Sri Lanka</h1>
        </div>
        <div class="auth-buttons">
    <?php if ($is_logged_in): ?>
        <!-- Si l'utilisateur est connecté, afficher le bouton Mon compte et Se déconnecter -->
        <a href="mon_compte.php" class="button">Mon compte</a>
        <form method="POST" action="home.php"> <!-- logout.php pour gérer la déconnexion -->
            <button type="submit" name="logout" class="button">Se déconnecter</button>
        </form>
    <?php else: ?>
        <a href="inscription.php" class="button">Inscription</a>
        <a href="connexion.php" class="button">Connexion</a>
    <?php endif; ?>
</div>
    </header>

    <!-- Second header avec les liens de navigation -->
    <nav class="main-nav">
        <ul>
            <li><a href="home.php">Accueil</a></li>
            <li><a href="culture.php">Culture</a></li>
            <li><a href="visa.php">Demande de visa</a></li>
            <li><a href="loterie.php">Loterie</a></li>
            <li><a href="home.php#contact">Contact</a></li>
        </ul>
    </nav>

    <!-- Contenu de la page culture -->
    <section class="culture-section">
        <center><h2>Culture du Sri Lanka</h2>
        <p class="intro">
            Découvrez la richesse et la diversité culturelle du Sri Lanka, un pays où les traditions anciennes et les influences modernes se rencontrent. Notre culture est un reflet de notre histoire, de notre diversité ethnique et de notre patrimoine vivant.
        </p></center>

        <!-- Culture Gastronomique -->
        <div class="culture-container">
            <div class="culture-item">
                <h2>Culture Gastronomique</h2>
                <p><strong>Plats Typiques :</strong></p>
                <ul>
                    <li><strong>Riz et Currys :</strong> Un plat de base incontournable, souvent servi avec une variété de currys.</li>
                    <li><strong>Hoppers :</strong> Une crêpe croustillante à base de farine de riz, souvent accompagnée d'œufs ou de lait de coco.</li>
                    <li><strong>Kottu :</strong> Un plat de rue populaire préparé avec des morceaux de roti, des légumes, et des épices.</li>
                </ul>
            </div>
            <div class="culture-images">
                <!-- Lien vers les images gastronomiques -->
                <img src="../images/image1.jpg" alt="Riz et Currys">
                <img src="../images/image2.jpg" alt="Kottu">
            </div>
        </div>

        <hr>

        <!-- Culture Sportive -->
        <div class="culture-container">
            <div class="culture-item">
                <h2>Culture Sportive</h2>
                <p><strong>Sports Populaires :</strong></p>
                <ul>
                    <li><strong>Cricket :</strong> Le sport national, avec des équipes renommées qui participent à des compétitions internationales.</li>
                    <li><strong>Rugby et Volleyball :</strong> Également très appréciés, avec une forte participation au niveau local.</li>
                </ul>
                <p><strong>Événements Majeurs :</strong> Suivez des événements sportifs comme le Championnat de Cricket, qui rassemble des foules enthousiastes à travers le pays.</p>
            </div>
            <div class="culture-images">
                <!-- Lien vers les images sportives -->
                <img src="../images/volley.png" alt="Sri Lanka Volleyball">
                <img src="../images/cricket.jpeg" alt="Sri Lanka Cricket">
            </div>
        </div>
        <hr>

        <!-- Culture Musicale -->
        <div class="culture-container">
            <div class="culture-item">
                <h2>Culture Musicale</h2>
                <p><strong>Musique Traditionnelle :</strong> Explorez des genres musicaux traditionnels, comme le <em>Baila</em> et le <em>Kandyan</em>, et découvrez des instruments emblématiques comme le <em>Ravana</em>.</p>
                <p><strong>Artistes Célèbres :</strong> Rencontrez des artistes influents et écoutez des morceaux modernes qui mélangent tradition et innovation.</p>
            </div>
            <div class="culture-images">
                <!-- Lien vers les images musicales -->
                <img src="../images/musique1.jpeg" alt="Musique Traditionnelle 1">
                <img src="../images/musique2.jpeg" alt="Musique Traditionnelle 2">
            </div>
        </div>

        <hr>

        <!-- Autres Aspects Culturels -->
        <div class="culture-container">
            <div class="culture-item">
                <h2>Autres Aspects Culturels</h2>
                <p><strong>Art et Artisanat :</strong> Admirez le savoir-faire des artisans sri-lankais, qui créent des œuvres d'art uniques, allant de la sculpture au textile.</p>
                <p><strong>Festivals Importants :</strong> Découvrez des festivals comme le Vesak, qui célèbre la naissance, l'illumination et la mort de Bouddha, rassemblant des millions de personnes pour des célébrations colorées.</p>
                <p><strong>Croyances et Traditions :</strong> Un aperçu des pratiques religieuses variées et des coutumes qui font partie intégrante de la vie sri-lankaise.</p>
            </div>
            <div class="culture-images">
                <!-- Lien vers les images d'art et festivals -->
                <img src="../images/art1.jpg" alt="Art et Artisanat">
                <img src="../images/festival1.jpg" alt="Festival Important">
            </div>
        </div>
    </section>

    <footer>
    <p>&copy; 2023 Consulat du Sri Lanka. Tous droits réservés.</p>
    <p>16 Rue Spontini, 75016 Paris | Téléphone : 0155733131 | Horaires : Lundi à Vendredi : 9h00 - 17h00</p>
    <div class="footer-links">
        <a href="#">Politique de confidentialité</a> | 
        <a href="#">Conditions d'utilisation</a>
    </div>
</footer>

</body>
</html>
