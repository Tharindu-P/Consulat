<?php
session_start();  // Démarre la session

// Si l'utilisateur est déjà connecté, rediriger vers la page d'accueil
if (isset($_SESSION['email'])) {
    header('Location: home.php');
    exit();
}

$errors = [];  // Tableau pour stocker les erreurs

// Configurations de la base de données
$host = 'localhost';
$db = 'monprojet_db';
$user = 'Tharindu'; // Remplace par ton nom d'utilisateur MySQL
$password = ''; // Remplace par ton mot de passe si tu en as défini un

// Établir la connexion à la base de données
$conn = new mysqli($host, $user, $password, $db);

// Vérifier la connexion
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['register'])) {
        // Traitement de l'inscription
        $first_name = htmlspecialchars($_POST['first_name']);
        $last_name = htmlspecialchars($_POST['last_name']);
        $email = htmlspecialchars($_POST['email']);
        $phone = htmlspecialchars($_POST['phone']);
        $nationality = htmlspecialchars($_POST['nationality']);
        $other_nationality = htmlspecialchars($_POST['other_nationality']);  // Récupère la nationalité "Autre"
        $password = htmlspecialchars($_POST['password']);
        $confirm_password = htmlspecialchars($_POST['confirm_password']);
        
        // Si "Autre" est sélectionné, on prend la valeur de "other_nationality"
        if ($nationality === 'Autre' && !empty($other_nationality)) {
            $nationality = $other_nationality;
        }

        // Regex pour valider l'email
        $email_regex = "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/";
        
        // Vérification des champs
        if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($nationality) || empty($password) || empty($confirm_password)) {
            $errors[] = "Veuillez remplir tous les champs.";
        }
        if (!preg_match("/^[A-Za-zÀ-ÿ '-]+$/", $first_name)) {
            $errors[] = "Le prénom est invalide.";
        }
        if (!preg_match("/^[A-Za-zÀ-ÿ '-]+$/", $last_name)) {
            $errors[] = "Le nom est invalide.";
        }
        if (!preg_match("/^\+?\d{10,15}$/", $phone)) {
            $errors[] = "Le numéro de téléphone est invalide.";
        }
        if (!preg_match($email_regex, $email)) {
            $errors[] = "L'email est invalide. Assurez-vous qu'il contient un '@' et un domaine valide.";
        }
        if (!preg_match("/^(?=.*[A-Z])(?=.*\d)(?=.*[\W_])[A-Za-z\d\W_]{8,}$/", $password)) {
            $errors[] = "Le mot de passe doit contenir au moins 8 caractères, une majuscule, un chiffre et un caractère spécial.";
        }
        
        if ($password !== $confirm_password) {
            $errors[] = "Les mots de passe ne correspondent pas.";
        }

        // Vérification si l'email existe déjà dans la base de données
        if (empty($errors)) {
            $query = "SELECT * FROM users WHERE email = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $errors[] = "L'adresse email est déjà utilisée. Veuillez en choisir une autre.";
            }
            $stmt->close();
        }

        if (empty($errors)) {
            // Cryptage du mot de passe
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Déterminer si la nationalité est "Sri Lanka"
            $est_national = ($nationality === "Sri Lanka") ? 1 : 0;

            // Préparation de la requête d'insertion
            $stmt = $conn->prepare("INSERT INTO users (nom, prenom, email, telephone, nationalite, mot_de_passe, est_national) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssi", $first_name, $last_name, $email, $phone, $nationality, $hashed_password, $est_national);

            // Exécution de la requête
            if ($stmt->execute()) {
                // Si l'insertion est réussie, enregistrer les informations de l'utilisateur dans la session
                $_SESSION['email'] = $email;
                $_SESSION['first_name'] = $first_name;
                $_SESSION['last_name'] = $last_name;
                $_SESSION['phone'] = $phone;
                $_SESSION['nationality'] = $nationality;
                header('Location: home.php');  // Redirige vers la page d'accueil
                exit();
            } else {
                $errors[] = "Une erreur est survenue lors de l'inscription.";
            }

            // Fermer la requête préparée
            $stmt->close();
        }
    }
}

// Récupérer la liste des pays depuis la base de données
$query = "SELECT name FROM countries ORDER BY name ASC";
$result = $conn->query($query);

// Fermer la connexion
$conn->close();
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link rel="stylesheet" href="../style/connexion.css">
    <style>
        /* Conteneur des champs de mot de passe */
        .password-container {
            display: flex;
            flex-direction: column; /* Empile les champs de mot de passe */
            width: 100%;
            margin-bottom: 15px;
        }

        .password-container input {
            width: 100%; /* Prend toute la largeur */
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        /* Style pour le bouton */
        #togglePasswordButton {
            background: none;
            border: none;
            color: #8f1841;
            cursor: pointer;
            font-size: 14px;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header class="top-header">
        <div class="logo-container">
            <img src="../images/drapeau_sri_lanka.jpg" alt="Drapeau du Sri Lanka" class="flag-img">
            <h1>Consulat du Sri Lanka</h1>
        </div>
        <div class="auth-buttons">
            <a href="inscription.php" class="button">Inscription</a>
            <a href="connexion.php" class="button">Connexion</a>
        </div>
    </header>

    <nav class="main-nav">
        <ul>
            <li><a href="home.php">Accueil</a></li>
            <li><a href="culture.php">Culture</a></li>
            <li><a href="visa.php">Demande de visa</a></li>
            <li><a href="loterie.php">Loterie</a></li>
            <li><a href="home.php#contact">Contact</a></li>
        </ul>
    </nav>

    <main>
        <section class="welcome">
            <h2>Création de compte</h2>
            <?php if (!empty($errors)): ?>
                <script>
                    alert("<?php echo implode("\\n", $errors); ?>");
                </script>
            <?php endif; ?>
            
            <div class="form-container">
                <form method="POST">
                    <label for="first_name">Nom</label>
                    <input type="text" name="first_name" id="first_name" value="<?php echo isset($first_name) ? $first_name : ''; ?>" required>

                    <label for="last_name">Prénom</label>
                    <input type="text" name="last_name" id="last_name" value="<?php echo isset($last_name) ? $last_name : ''; ?>" required>

                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo isset($email) ? $email : ''; ?>" required>

                    <label for="phone">Numéro de téléphone</label>
                    <input type="tel" name="phone" id="phone" value="<?php echo isset($phone) ? $phone : ''; ?>" required>

                    <label for="nationality">Nationalité</label>
                    <select name="nationality" id="nationality" required>
                        <option value="">Sélectionnez votre nationalité</option>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<option value="' . htmlspecialchars($row['name']) . '" ' . (isset($nationality) && $nationality == $row['name'] ? 'selected' : '') . '>' . htmlspecialchars($row['name']) . '</option>';
                            }
                        }
                        ?>
                        <option value="Autre" <?php echo (isset($nationality) && $nationality == 'Autre') ? 'selected' : ''; ?>>Autre...</option>
                    </select>

                    <div class="password-container">
                        <label for="password">Mot de passe</label>
                        <input type="password" name="password" id="password" required>

                        <label for="confirm_password">Confirmer le mot de passe</label>
                        <input type="password" name="confirm_password" id="confirm_password" required>
                    </div>

                    <button type="button" id="togglePasswordButton" onclick="togglePassword()">Afficher le mot de passe</button>

                    <button type="submit" name="register">Créer un compte</button>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2023 Consulat du Sri Lanka. Tous droits réservés.</p>
    </footer>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById('password');
            var confirmPasswordField = document.getElementById('confirm_password');
            var button = document.getElementById('togglePasswordButton');
            
            if (passwordField.type === "password") {
                passwordField.type = "text";
                confirmPasswordField.type = "text";
                button.textContent = "Masquer le mot de passe"; 
            } else {
                passwordField.type = "password";
                confirmPasswordField.type = "password";
                button.textContent = "Afficher le mot de passe"; 
            }
        }
    </script>
</body>
</html>
