<?php

require_once 'vendor/autoload.php'; // Charger l'autoload de Composer pour utiliser Faker

// Configurations de la base de données
$host = 'localhost';
$dbname = 'monprojet_db'; // Nom de votre base de données
$username = 'Tharindu'; // Nom d'utilisateur MySQL
$password = ''; // Mot de passe MySQL (vide si vous n'en avez pas défini)

try {
    // Connexion à la base de données avec PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connexion à la base de données réussie.\n";
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
    exit;
}

// Initialisation de Faker pour générer des données
$faker = Faker\Factory::create('fr_FR'); // Générer des données en français

// Fonction personnalisée pour générer un mot de passe sécurisé
function genererMotDePasse() {
    $majuscule = chr(rand(65, 90)); // Lettre majuscule
    $minuscule = chr(rand(97, 122)); // Lettre minuscule
    $chiffre = chr(rand(48, 57)); // Chiffre
    $special = '@$!%*?&'; // Caractères spéciaux autorisés
    $caractere_special = $special[rand(0, strlen($special) - 1)]; // Un caractère spécial au hasard

    // Générer le reste du mot de passe avec des lettres et chiffres
    $reste = substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 4);

    // Combiner les caractères pour créer le mot de passe
    return str_shuffle($majuscule . $minuscule . $chiffre . $caractere_special . $reste);
}

// Générer et insérer 100 utilisateurs
for ($i = 0; $i < 100; $i++) {
    // Données générées par Faker
    $first_name = $faker->firstName;
    $last_name = $faker->lastName;
    $email = $faker->unique()->safeEmail;
    $phone = $faker->phoneNumber;
    $nationality = $faker->country;
    $passport_number = substr($faker->uuid, 0, 10); // Limite à 10 caractères pour éviter l'erreur SQL
    $passport_validity_date = $faker->date('Y-m-d', '2030-12-31'); // Date de validité du passeport

    // Générer un mot de passe répondant aux exigences
    $password = genererMotDePasse();
    $confirm_password = $password;

    // Vérification des regex (si nécessaire)
    $errors = [];

    // Vérification des champs
    if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($nationality) || empty($password) || empty($confirm_password)) {
        $errors[] = "Veuillez remplir tous les champs.";
    }

    // Vérification du prénom et nom
    if (!preg_match("/^[A-Za-zÀ-ÿ '-]+$/", $first_name)) {
        $errors[] = "Le prénom est invalide.";
    }

    if (!preg_match("/^[A-Za-zÀ-ÿ '-]+$/", $last_name)) {
        $errors[] = "Le nom est invalide.";
    }

    // Vérification du numéro de téléphone
    // Modifier la regex pour que les numéros de téléphone générés par Faker soient acceptés
    if (!preg_match("/^\+?\d{10,15}$/", preg_replace("/[^0-9+]/", "", $phone))) {
        $errors[] = "Le numéro de téléphone est invalide.";
    }

    // Vérification de l'email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "L'email est invalide.";
    }

    // Vérification du mot de passe (ajout d'une meilleure vérification)
    if (!preg_match("/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&_])[A-Za-z\d@$!%*?&_]{8,}$/", $password)) {
        $errors[] = "Le mot de passe doit contenir au moins 8 caractères, une majuscule, un chiffre et un caractère spécial.";
    }

    // Vérification si les mots de passe correspondent
    if ($password !== $confirm_password) {
        $errors[] = "Les mots de passe ne correspondent pas.";
    }

    // Si aucune erreur, on insère l'utilisateur dans la base de données
    if (empty($errors)) {
        // Préparer la requête d'insertion
        $sql = "INSERT INTO users (nom, prenom, email, telephone, nationalite, num_passeport, date_validite_passeport, mot_de_passe)
                VALUES (:nom, :prenom, :email, :telephone, :nationalite, :num_passeport, :date_validite_passeport, :mot_de_passe)";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':nom' => $last_name,
            ':prenom' => $first_name,
            ':email' => $email,
            ':telephone' => preg_replace("/[^0-9+]/", "", $phone), // Nettoyer le numéro de téléphone
            ':nationalite' => $nationality,
            ':num_passeport' => $passport_number,
            ':date_validite_passeport' => $passport_validity_date,
            ':mot_de_passe' => password_hash($password, PASSWORD_BCRYPT) // Hachage du mot de passe
        ]);
        echo "Utilisateur $first_name $last_name ajouté avec succès.\n";
    } else {
        echo "Erreur pour $first_name $last_name : " . implode(", ", $errors) . "\n";
    }
}

echo "100 utilisateurs ont été ajoutés à la base de données.\n";

?>
